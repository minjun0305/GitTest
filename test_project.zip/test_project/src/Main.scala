package pp2017.submission

object Main {
  def foo(n:Int) = n + 2
  def bar(n:Int) = n + 5
}
