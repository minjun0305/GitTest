#!/usr/bin/env bash

scala -cp classes pp2017.test.Test
